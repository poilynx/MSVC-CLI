

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 7.00.0555 */
/* Compiler settings for audiopolicy.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 7.00.0555 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

/* verify that the <rpcsal.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCSAL_H_VERSION__
#define __REQUIRED_RPCSAL_H_VERSION__ 100
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __audiopolicy_h__
#define __audiopolicy_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IAudioSessionEvents_FWD_DEFINED__
#define __IAudioSessionEvents_FWD_DEFINED__
typedef interface IAudioSessionEvents IAudioSessionEvents;
#endif 	/* __IAudioSessionEvents_FWD_DEFINED__ */


#ifndef __IAudioSessionControl_FWD_DEFINED__
#define __IAudioSessionControl_FWD_DEFINED__
typedef interface IAudioSessionControl IAudioSessionControl;
#endif 	/* __IAudioSessionControl_FWD_DEFINED__ */


#ifndef __IAudioSessionControl2_FWD_DEFINED__
#define __IAudioSessionControl2_FWD_DEFINED__
typedef interface IAudioSessionControl2 IAudioSessionControl2;
#endif 	/* __IAudioSessionControl2_FWD_DEFINED__ */


#ifndef __IAudioSessionManager_FWD_DEFINED__
#define __IAudioSessionManager_FWD_DEFINED__
typedef interface IAudioSessionManager IAudioSessionManager;
#endif 	/* __IAudioSessionManager_FWD_DEFINED__ */


#ifndef __IAudioVolumeDuckNotification_FWD_DEFINED__
#define __IAudioVolumeDuckNotification_FWD_DEFINED__
typedef interface IAudioVolumeDuckNotification IAudioVolumeDuckNotification;
#endif 	/* __IAudioVolumeDuckNotification_FWD_DEFINED__ */


#ifndef __IAudioSessionNotification_FWD_DEFINED__
#define __IAudioSessionNotification_FWD_DEFINED__
typedef interface IAudioSessionNotification IAudioSessionNotification;
#endif 	/* __IAudioSessionNotification_FWD_DEFINED__ */


#ifndef __IAudioSessionEnumerator_FWD_DEFINED__
#define __IAudioSessionEnumerator_FWD_DEFINED__
typedef interface IAudioSessionEnumerator IAudioSessionEnumerator;
#endif 	/* __IAudioSessionEnumerator_FWD_DEFINED__ */


#ifndef __IAudioSessionManager2_FWD_DEFINED__
#define __IAudioSessionManager2_FWD_DEFINED__
typedef interface IAudioSessionManager2 IAudioSessionManager2;
#endif 	/* __IAudioSessionManager2_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"
#include "propidl.h"
#include "AudioSessionTypes.h"
#include "AudioClient.h"

#ifdef __cplusplus
extern "C"{
#endif 


/* interface __MIDL_itf_audiopolicy_0000_0000 */
/* [local] */ 

typedef 
enum AudioSessionDisconnectReason
    {	DisconnectReasonDeviceRemoval	= 0,
	DisconnectReasonServerShutdown	= ( DisconnectReasonDeviceRemoval + 1 ) ,
	DisconnectReasonFormatChanged	= ( DisconnectReasonServerShutdown + 1 ) ,
	DisconnectReasonSessionLogoff	= ( DisconnectReasonFormatChanged + 1 ) ,
	DisconnectReasonSessionDisconnected	= ( DisconnectReasonSessionLogoff + 1 ) ,
	DisconnectReasonExclusiveModeOverride	= ( DisconnectReasonSessionDisconnected + 1 ) 
    } 	AudioSessionDisconnectReason;



extern RPC_IF_HANDLE __MIDL_itf_audiopolicy_0000_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_audiopolicy_0000_0000_v0_0_s_ifspec;

#ifndef __IAudioSessionEvents_INTERFACE_DEFINED__
#define __IAudioSessionEvents_INTERFACE_DEFINED__

/* interface IAudioSessionEvents */
/* [local][uuid][unique][object] */ 


EXTERN_C const IID IID_IAudioSessionEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("24918ACC-64B3-37C1-8CA9-74A66E9957A8")
    IAudioSessionEvents : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE OnDisplayNameChanged( 
            /* [annotation][string][in] */ 
            __in  LPCWSTR NewDisplayName,
            /* [in] */ LPCGUID EventContext) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnIconPathChanged( 
            /* [annotation][string][in] */ 
            __in  LPCWSTR NewIconPath,
            /* [in] */ LPCGUID EventContext) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnSimpleVolumeChanged( 
            /* [annotation][in] */ 
            __in  float NewVolume,
            /* [annotation][in] */ 
            __in  BOOL NewMute,
            /* [in] */ LPCGUID EventContext) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnChannelVolumeChanged( 
            /* [annotation][in] */ 
            __in  DWORD ChannelCount,
            /* [annotation][size_is][in] */ 
            __in_ecount(ChannelCount)  float NewChannelVolumeArray[  ],
            /* [annotation][in] */ 
            __in  DWORD ChangedChannel,
            /* [in] */ LPCGUID EventContext) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnGroupingParamChanged( 
            /* [annotation][in] */ 
            __in  LPCGUID NewGroupingParam,
            /* [in] */ LPCGUID EventContext) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnStateChanged( 
            /* [annotation][in] */ 
            __in  AudioSessionState NewState) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnSessionDisconnected( 
            /* [annotation][in] */ 
            __in  AudioSessionDisconnectReason DisconnectReason) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IAudioSessionEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IAudioSessionEvents * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IAudioSessionEvents * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IAudioSessionEvents * This);
        
        HRESULT ( STDMETHODCALLTYPE *OnDisplayNameChanged )( 
            IAudioSessionEvents * This,
            /* [annotation][string][in] */ 
            __in  LPCWSTR NewDisplayName,
            /* [in] */ LPCGUID EventContext);
        
        HRESULT ( STDMETHODCALLTYPE *OnIconPathChanged )( 
            IAudioSessionEvents * This,
            /* [annotation][string][in] */ 
            __in  LPCWSTR NewIconPath,
            /* [in] */ LPCGUID EventContext);
        
        HRESULT ( STDMETHODCALLTYPE *OnSimpleVolumeChanged )( 
            IAudioSessionEvents * This,
            /* [annotation][in] */ 
            __in  float NewVolume,
            /* [annotation][in] */ 
            __in  BOOL NewMute,
            /* [in] */ LPCGUID EventContext);
        
        HRESULT ( STDMETHODCALLTYPE *OnChannelVolumeChanged )( 
            IAudioSessionEvents * This,
            /* [annotation][in] */ 
            __in  DWORD ChannelCount,
            /* [annotation][size_is][in] */ 
            __in_ecount(ChannelCount)  float NewChannelVolumeArray[  ],
            /* [annotation][in] */ 
            __in  DWORD ChangedChannel,
            /* [in] */ LPCGUID EventContext);
        
        HRESULT ( STDMETHODCALLTYPE *OnGroupingParamChanged )( 
            IAudioSessionEvents * This,
            /* [annotation][in] */ 
            __in  LPCGUID NewGroupingParam,
            /* [in] */ LPCGUID EventContext);
        
        HRESULT ( STDMETHODCALLTYPE *OnStateChanged )( 
            IAudioSessionEvents * This,
            /* [annotation][in] */ 
            __in  AudioSessionState NewState);
        
        HRESULT ( STDMETHODCALLTYPE *OnSessionDisconnected )( 
            IAudioSessionEvents * This,
            /* [annotation][in] */ 
            __in  AudioSessionDisconnectReason DisconnectReason);
        
        END_INTERFACE
    } IAudioSessionEventsVtbl;

    interface IAudioSessionEvents
    {
        CONST_VTBL struct IAudioSessionEventsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IAudioSessionEvents_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IAudioSessionEvents_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IAudioSessionEvents_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IAudioSessionEvents_OnDisplayNameChanged(This,NewDisplayName,EventContext)	\
    ( (This)->lpVtbl -> OnDisplayNameChanged(This,NewDisplayName,EventContext) ) 

#define IAudioSessionEvents_OnIconPathChanged(This,NewIconPath,EventContext)	\
    ( (This)->lpVtbl -> OnIconPathChanged(This,NewIconPath,EventContext) ) 

#define IAudioSessionEvents_OnSimpleVolumeChanged(This,NewVolume,NewMute,EventContext)	\
    ( (This)->lpVtbl -> OnSimpleVolumeChanged(This,NewVolume,NewMute,EventContext) ) 

#define IAudioSessionEvents_OnChannelVolumeChanged(This,ChannelCount,NewChannelVolumeArray,ChangedChannel,EventContext)	\
    ( (This)->lpVtbl -> OnChannelVolumeChanged(This,ChannelCount,NewChannelVolumeArray,ChangedChannel,EventContext) ) 

#define IAudioSessionEvents_OnGroupingParamChanged(This,NewGroupingParam,EventContext)	\
    ( (This)->lpVtbl -> OnGroupingParamChanged(This,NewGroupingParam,EventContext) ) 

#define IAudioSessionEvents_OnStateChanged(This,NewState)	\
    ( (This)->lpVtbl -> OnStateChanged(This,NewState) ) 

#define IAudioSessionEvents_OnSessionDisconnected(This,DisconnectReason)	\
    ( (This)->lpVtbl -> OnSessionDisconnected(This,DisconnectReason) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IAudioSessionEvents_INTERFACE_DEFINED__ */


#ifndef __IAudioSessionControl_INTERFACE_DEFINED__
#define __IAudioSessionControl_INTERFACE_DEFINED__

/* interface IAudioSessionControl */
/* [local][unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IAudioSessionControl;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("F4B1A599-7266-4319-A8CA-E70ACB11E8CD")
    IAudioSessionControl : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetState( 
            /* [annotation][out] */ 
            __out  AudioSessionState *pRetVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetDisplayName( 
            /* [annotation][string][out] */ 
            __out  LPWSTR *pRetVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetDisplayName( 
            /* [annotation][string][in] */ 
            __in  LPCWSTR Value,
            /* [unique][in] */ LPCGUID EventContext) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetIconPath( 
            /* [annotation][string][out] */ 
            __out  LPWSTR *pRetVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetIconPath( 
            /* [annotation][string][in] */ 
            __in  LPCWSTR Value,
            /* [unique][in] */ LPCGUID EventContext) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetGroupingParam( 
            /* [annotation][out] */ 
            __out  GUID *pRetVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetGroupingParam( 
            /* [annotation][in] */ 
            __in  LPCGUID Override,
            /* [unique][in] */ LPCGUID EventContext) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RegisterAudioSessionNotification( 
            /* [annotation][in] */ 
            __in  IAudioSessionEvents *NewNotifications) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE UnregisterAudioSessionNotification( 
            /* [annotation][in] */ 
            __in  IAudioSessionEvents *NewNotifications) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IAudioSessionControlVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IAudioSessionControl * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IAudioSessionControl * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IAudioSessionControl * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetState )( 
            IAudioSessionControl * This,
            /* [annotation][out] */ 
            __out  AudioSessionState *pRetVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetDisplayName )( 
            IAudioSessionControl * This,
            /* [annotation][string][out] */ 
            __out  LPWSTR *pRetVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetDisplayName )( 
            IAudioSessionControl * This,
            /* [annotation][string][in] */ 
            __in  LPCWSTR Value,
            /* [unique][in] */ LPCGUID EventContext);
        
        HRESULT ( STDMETHODCALLTYPE *GetIconPath )( 
            IAudioSessionControl * This,
            /* [annotation][string][out] */ 
            __out  LPWSTR *pRetVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetIconPath )( 
            IAudioSessionControl * This,
            /* [annotation][string][in] */ 
            __in  LPCWSTR Value,
            /* [unique][in] */ LPCGUID EventContext);
        
        HRESULT ( STDMETHODCALLTYPE *GetGroupingParam )( 
            IAudioSessionControl * This,
            /* [annotation][out] */ 
            __out  GUID *pRetVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetGroupingParam )( 
            IAudioSessionControl * This,
            /* [annotation][in] */ 
            __in  LPCGUID Override,
            /* [unique][in] */ LPCGUID EventContext);
        
        HRESULT ( STDMETHODCALLTYPE *RegisterAudioSessionNotification )( 
            IAudioSessionControl * This,
            /* [annotation][in] */ 
            __in  IAudioSessionEvents *NewNotifications);
        
        HRESULT ( STDMETHODCALLTYPE *UnregisterAudioSessionNotification )( 
            IAudioSessionControl * This,
            /* [annotation][in] */ 
            __in  IAudioSessionEvents *NewNotifications);
        
        END_INTERFACE
    } IAudioSessionControlVtbl;

    interface IAudioSessionControl
    {
        CONST_VTBL struct IAudioSessionControlVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IAudioSessionControl_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IAudioSessionControl_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IAudioSessionControl_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IAudioSessionControl_GetState(This,pRetVal)	\
    ( (This)->lpVtbl -> GetState(This,pRetVal) ) 

#define IAudioSessionControl_GetDisplayName(This,pRetVal)	\
    ( (This)->lpVtbl -> GetDisplayName(This,pRetVal) ) 

#define IAudioSessionControl_SetDisplayName(This,Value,EventContext)	\
    ( (This)->lpVtbl -> SetDisplayName(This,Value,EventContext) ) 

#define IAudioSessionControl_GetIconPath(This,pRetVal)	\
    ( (This)->lpVtbl -> GetIconPath(This,pRetVal) ) 

#define IAudioSessionControl_SetIconPath(This,Value,EventContext)	\
    ( (This)->lpVtbl -> SetIconPath(This,Value,EventContext) ) 

#define IAudioSessionControl_GetGroupingParam(This,pRetVal)	\
    ( (This)->lpVtbl -> GetGroupingParam(This,pRetVal) ) 

#define IAudioSessionControl_SetGroupingParam(This,Override,EventContext)	\
    ( (This)->lpVtbl -> SetGroupingParam(This,Override,EventContext) ) 

#define IAudioSessionControl_RegisterAudioSessionNotification(This,NewNotifications)	\
    ( (This)->lpVtbl -> RegisterAudioSessionNotification(This,NewNotifications) ) 

#define IAudioSessionControl_UnregisterAudioSessionNotification(This,NewNotifications)	\
    ( (This)->lpVtbl -> UnregisterAudioSessionNotification(This,NewNotifications) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IAudioSessionControl_INTERFACE_DEFINED__ */


#ifndef __IAudioSessionControl2_INTERFACE_DEFINED__
#define __IAudioSessionControl2_INTERFACE_DEFINED__

/* interface IAudioSessionControl2 */
/* [local][unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IAudioSessionControl2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("bfb7ff88-7239-4fc9-8fa2-07c950be9c6d")
    IAudioSessionControl2 : public IAudioSessionControl
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetSessionIdentifier( 
            /* [annotation][string][out] */ 
            __out  LPWSTR *pRetVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetSessionInstanceIdentifier( 
            /* [annotation][string][out] */ 
            __out  LPWSTR *pRetVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetProcessId( 
            /* [annotation][out] */ 
            __out  DWORD *pRetVal) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE IsSystemSoundsSession( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE SetDuckingPreference( 
            /* [in] */ BOOL optOut) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IAudioSessionControl2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IAudioSessionControl2 * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IAudioSessionControl2 * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IAudioSessionControl2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetState )( 
            IAudioSessionControl2 * This,
            /* [annotation][out] */ 
            __out  AudioSessionState *pRetVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetDisplayName )( 
            IAudioSessionControl2 * This,
            /* [annotation][string][out] */ 
            __out  LPWSTR *pRetVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetDisplayName )( 
            IAudioSessionControl2 * This,
            /* [annotation][string][in] */ 
            __in  LPCWSTR Value,
            /* [unique][in] */ LPCGUID EventContext);
        
        HRESULT ( STDMETHODCALLTYPE *GetIconPath )( 
            IAudioSessionControl2 * This,
            /* [annotation][string][out] */ 
            __out  LPWSTR *pRetVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetIconPath )( 
            IAudioSessionControl2 * This,
            /* [annotation][string][in] */ 
            __in  LPCWSTR Value,
            /* [unique][in] */ LPCGUID EventContext);
        
        HRESULT ( STDMETHODCALLTYPE *GetGroupingParam )( 
            IAudioSessionControl2 * This,
            /* [annotation][out] */ 
            __out  GUID *pRetVal);
        
        HRESULT ( STDMETHODCALLTYPE *SetGroupingParam )( 
            IAudioSessionControl2 * This,
            /* [annotation][in] */ 
            __in  LPCGUID Override,
            /* [unique][in] */ LPCGUID EventContext);
        
        HRESULT ( STDMETHODCALLTYPE *RegisterAudioSessionNotification )( 
            IAudioSessionControl2 * This,
            /* [annotation][in] */ 
            __in  IAudioSessionEvents *NewNotifications);
        
        HRESULT ( STDMETHODCALLTYPE *UnregisterAudioSessionNotification )( 
            IAudioSessionControl2 * This,
            /* [annotation][in] */ 
            __in  IAudioSessionEvents *NewNotifications);
        
        HRESULT ( STDMETHODCALLTYPE *GetSessionIdentifier )( 
            IAudioSessionControl2 * This,
            /* [annotation][string][out] */ 
            __out  LPWSTR *pRetVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetSessionInstanceIdentifier )( 
            IAudioSessionControl2 * This,
            /* [annotation][string][out] */ 
            __out  LPWSTR *pRetVal);
        
        HRESULT ( STDMETHODCALLTYPE *GetProcessId )( 
            IAudioSessionControl2 * This,
            /* [annotation][out] */ 
            __out  DWORD *pRetVal);
        
        HRESULT ( STDMETHODCALLTYPE *IsSystemSoundsSession )( 
            IAudioSessionControl2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *SetDuckingPreference )( 
            IAudioSessionControl2 * This,
            /* [in] */ BOOL optOut);
        
        END_INTERFACE
    } IAudioSessionControl2Vtbl;

    interface IAudioSessionControl2
    {
        CONST_VTBL struct IAudioSessionControl2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IAudioSessionControl2_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IAudioSessionControl2_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IAudioSessionControl2_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IAudioSessionControl2_GetState(This,pRetVal)	\
    ( (This)->lpVtbl -> GetState(This,pRetVal) ) 

#define IAudioSessionControl2_GetDisplayName(This,pRetVal)	\
    ( (This)->lpVtbl -> GetDisplayName(This,pRetVal) ) 

#define IAudioSessionControl2_SetDisplayName(This,Value,EventContext)	\
    ( (This)->lpVtbl -> SetDisplayName(This,Value,EventContext) ) 

#define IAudioSessionControl2_GetIconPath(This,pRetVal)	\
    ( (This)->lpVtbl -> GetIconPath(This,pRetVal) ) 

#define IAudioSessionControl2_SetIconPath(This,Value,EventContext)	\
    ( (This)->lpVtbl -> SetIconPath(This,Value,EventContext) ) 

#define IAudioSessionControl2_GetGroupingParam(This,pRetVal)	\
    ( (This)->lpVtbl -> GetGroupingParam(This,pRetVal) ) 

#define IAudioSessionControl2_SetGroupingParam(This,Override,EventContext)	\
    ( (This)->lpVtbl -> SetGroupingParam(This,Override,EventContext) ) 

#define IAudioSessionControl2_RegisterAudioSessionNotification(This,NewNotifications)	\
    ( (This)->lpVtbl -> RegisterAudioSessionNotification(This,NewNotifications) ) 

#define IAudioSessionControl2_UnregisterAudioSessionNotification(This,NewNotifications)	\
    ( (This)->lpVtbl -> UnregisterAudioSessionNotification(This,NewNotifications) ) 


#define IAudioSessionControl2_GetSessionIdentifier(This,pRetVal)	\
    ( (This)->lpVtbl -> GetSessionIdentifier(This,pRetVal) ) 

#define IAudioSessionControl2_GetSessionInstanceIdentifier(This,pRetVal)	\
    ( (This)->lpVtbl -> GetSessionInstanceIdentifier(This,pRetVal) ) 

#define IAudioSessionControl2_GetProcessId(This,pRetVal)	\
    ( (This)->lpVtbl -> GetProcessId(This,pRetVal) ) 

#define IAudioSessionControl2_IsSystemSoundsSession(This)	\
    ( (This)->lpVtbl -> IsSystemSoundsSession(This) ) 

#define IAudioSessionControl2_SetDuckingPreference(This,optOut)	\
    ( (This)->lpVtbl -> SetDuckingPreference(This,optOut) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IAudioSessionControl2_INTERFACE_DEFINED__ */


#ifndef __IAudioSessionManager_INTERFACE_DEFINED__
#define __IAudioSessionManager_INTERFACE_DEFINED__

/* interface IAudioSessionManager */
/* [local][unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IAudioSessionManager;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("BFA971F1-4D5E-40BB-935E-967039BFBEE4")
    IAudioSessionManager : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetAudioSessionControl( 
            /* [annotation][in] */ 
            __in_opt  LPCGUID AudioSessionGuid,
            /* [annotation][in] */ 
            __in  DWORD StreamFlags,
            /* [annotation][out] */ 
            __deref_out  IAudioSessionControl **SessionControl) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetSimpleAudioVolume( 
            /* [annotation][in] */ 
            __in_opt  LPCGUID AudioSessionGuid,
            /* [annotation][in] */ 
            __in  DWORD StreamFlags,
            /* [annotation][out] */ 
            __deref_out  ISimpleAudioVolume **AudioVolume) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IAudioSessionManagerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IAudioSessionManager * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IAudioSessionManager * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IAudioSessionManager * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetAudioSessionControl )( 
            IAudioSessionManager * This,
            /* [annotation][in] */ 
            __in_opt  LPCGUID AudioSessionGuid,
            /* [annotation][in] */ 
            __in  DWORD StreamFlags,
            /* [annotation][out] */ 
            __deref_out  IAudioSessionControl **SessionControl);
        
        HRESULT ( STDMETHODCALLTYPE *GetSimpleAudioVolume )( 
            IAudioSessionManager * This,
            /* [annotation][in] */ 
            __in_opt  LPCGUID AudioSessionGuid,
            /* [annotation][in] */ 
            __in  DWORD StreamFlags,
            /* [annotation][out] */ 
            __deref_out  ISimpleAudioVolume **AudioVolume);
        
        END_INTERFACE
    } IAudioSessionManagerVtbl;

    interface IAudioSessionManager
    {
        CONST_VTBL struct IAudioSessionManagerVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IAudioSessionManager_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IAudioSessionManager_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IAudioSessionManager_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IAudioSessionManager_GetAudioSessionControl(This,AudioSessionGuid,StreamFlags,SessionControl)	\
    ( (This)->lpVtbl -> GetAudioSessionControl(This,AudioSessionGuid,StreamFlags,SessionControl) ) 

#define IAudioSessionManager_GetSimpleAudioVolume(This,AudioSessionGuid,StreamFlags,AudioVolume)	\
    ( (This)->lpVtbl -> GetSimpleAudioVolume(This,AudioSessionGuid,StreamFlags,AudioVolume) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IAudioSessionManager_INTERFACE_DEFINED__ */


#ifndef __IAudioVolumeDuckNotification_INTERFACE_DEFINED__
#define __IAudioVolumeDuckNotification_INTERFACE_DEFINED__

/* interface IAudioVolumeDuckNotification */
/* [local][unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IAudioVolumeDuckNotification;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("C3B284D4-6D39-4359-B3CF-B56DDB3BB39C")
    IAudioVolumeDuckNotification : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE OnVolumeDuckNotification( 
            /* [in] */ LPCWSTR sessionID,
            /* [in] */ UINT32 countCommunicationSessions) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE OnVolumeUnduckNotification( 
            /* [in] */ LPCWSTR sessionID) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IAudioVolumeDuckNotificationVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IAudioVolumeDuckNotification * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IAudioVolumeDuckNotification * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IAudioVolumeDuckNotification * This);
        
        HRESULT ( STDMETHODCALLTYPE *OnVolumeDuckNotification )( 
            IAudioVolumeDuckNotification * This,
            /* [in] */ LPCWSTR sessionID,
            /* [in] */ UINT32 countCommunicationSessions);
        
        HRESULT ( STDMETHODCALLTYPE *OnVolumeUnduckNotification )( 
            IAudioVolumeDuckNotification * This,
            /* [in] */ LPCWSTR sessionID);
        
        END_INTERFACE
    } IAudioVolumeDuckNotificationVtbl;

    interface IAudioVolumeDuckNotification
    {
        CONST_VTBL struct IAudioVolumeDuckNotificationVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IAudioVolumeDuckNotification_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IAudioVolumeDuckNotification_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IAudioVolumeDuckNotification_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IAudioVolumeDuckNotification_OnVolumeDuckNotification(This,sessionID,countCommunicationSessions)	\
    ( (This)->lpVtbl -> OnVolumeDuckNotification(This,sessionID,countCommunicationSessions) ) 

#define IAudioVolumeDuckNotification_OnVolumeUnduckNotification(This,sessionID)	\
    ( (This)->lpVtbl -> OnVolumeUnduckNotification(This,sessionID) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IAudioVolumeDuckNotification_INTERFACE_DEFINED__ */


#ifndef __IAudioSessionNotification_INTERFACE_DEFINED__
#define __IAudioSessionNotification_INTERFACE_DEFINED__

/* interface IAudioSessionNotification */
/* [local][unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IAudioSessionNotification;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("641DD20B-4D41-49CC-ABA3-174B9477BB08")
    IAudioSessionNotification : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE OnSessionCreated( 
            /* [in] */ IAudioSessionControl *NewSession) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IAudioSessionNotificationVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IAudioSessionNotification * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IAudioSessionNotification * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IAudioSessionNotification * This);
        
        HRESULT ( STDMETHODCALLTYPE *OnSessionCreated )( 
            IAudioSessionNotification * This,
            /* [in] */ IAudioSessionControl *NewSession);
        
        END_INTERFACE
    } IAudioSessionNotificationVtbl;

    interface IAudioSessionNotification
    {
        CONST_VTBL struct IAudioSessionNotificationVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IAudioSessionNotification_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IAudioSessionNotification_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IAudioSessionNotification_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IAudioSessionNotification_OnSessionCreated(This,NewSession)	\
    ( (This)->lpVtbl -> OnSessionCreated(This,NewSession) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IAudioSessionNotification_INTERFACE_DEFINED__ */


#ifndef __IAudioSessionEnumerator_INTERFACE_DEFINED__
#define __IAudioSessionEnumerator_INTERFACE_DEFINED__

/* interface IAudioSessionEnumerator */
/* [local][unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IAudioSessionEnumerator;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("E2F5BB11-0570-40CA-ACDD-3AA01277DEE8")
    IAudioSessionEnumerator : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetCount( 
            /* [out] */ int *SessionCount) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetSession( 
            /* [in] */ int SessionCount,
            /* [out] */ IAudioSessionControl **Session) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IAudioSessionEnumeratorVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IAudioSessionEnumerator * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IAudioSessionEnumerator * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IAudioSessionEnumerator * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetCount )( 
            IAudioSessionEnumerator * This,
            /* [out] */ int *SessionCount);
        
        HRESULT ( STDMETHODCALLTYPE *GetSession )( 
            IAudioSessionEnumerator * This,
            /* [in] */ int SessionCount,
            /* [out] */ IAudioSessionControl **Session);
        
        END_INTERFACE
    } IAudioSessionEnumeratorVtbl;

    interface IAudioSessionEnumerator
    {
        CONST_VTBL struct IAudioSessionEnumeratorVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IAudioSessionEnumerator_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IAudioSessionEnumerator_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IAudioSessionEnumerator_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IAudioSessionEnumerator_GetCount(This,SessionCount)	\
    ( (This)->lpVtbl -> GetCount(This,SessionCount) ) 

#define IAudioSessionEnumerator_GetSession(This,SessionCount,Session)	\
    ( (This)->lpVtbl -> GetSession(This,SessionCount,Session) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IAudioSessionEnumerator_INTERFACE_DEFINED__ */


#ifndef __IAudioSessionManager2_INTERFACE_DEFINED__
#define __IAudioSessionManager2_INTERFACE_DEFINED__

/* interface IAudioSessionManager2 */
/* [local][unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_IAudioSessionManager2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("77AA99A0-1BD6-484F-8BC7-2C654C9A9B6F")
    IAudioSessionManager2 : public IAudioSessionManager
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetSessionEnumerator( 
            /* [retval][out] */ IAudioSessionEnumerator **SessionEnum) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RegisterSessionNotification( 
            IAudioSessionNotification *SessionNotification) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE UnregisterSessionNotification( 
            IAudioSessionNotification *SessionNotification) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE RegisterDuckNotification( 
            /* [string][in] */ LPCWSTR sessionID,
            /* [annotation][in] */ 
            __in  IAudioVolumeDuckNotification *duckNotification) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE UnregisterDuckNotification( 
            /* [annotation][in] */ 
            __in  IAudioVolumeDuckNotification *duckNotification) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IAudioSessionManager2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IAudioSessionManager2 * This,
            /* [in] */ REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IAudioSessionManager2 * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IAudioSessionManager2 * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetAudioSessionControl )( 
            IAudioSessionManager2 * This,
            /* [annotation][in] */ 
            __in_opt  LPCGUID AudioSessionGuid,
            /* [annotation][in] */ 
            __in  DWORD StreamFlags,
            /* [annotation][out] */ 
            __deref_out  IAudioSessionControl **SessionControl);
        
        HRESULT ( STDMETHODCALLTYPE *GetSimpleAudioVolume )( 
            IAudioSessionManager2 * This,
            /* [annotation][in] */ 
            __in_opt  LPCGUID AudioSessionGuid,
            /* [annotation][in] */ 
            __in  DWORD StreamFlags,
            /* [annotation][out] */ 
            __deref_out  ISimpleAudioVolume **AudioVolume);
        
        HRESULT ( STDMETHODCALLTYPE *GetSessionEnumerator )( 
            IAudioSessionManager2 * This,
            /* [retval][out] */ IAudioSessionEnumerator **SessionEnum);
        
        HRESULT ( STDMETHODCALLTYPE *RegisterSessionNotification )( 
            IAudioSessionManager2 * This,
            IAudioSessionNotification *SessionNotification);
        
        HRESULT ( STDMETHODCALLTYPE *UnregisterSessionNotification )( 
            IAudioSessionManager2 * This,
            IAudioSessionNotification *SessionNotification);
        
        HRESULT ( STDMETHODCALLTYPE *RegisterDuckNotification )( 
            IAudioSessionManager2 * This,
            /* [string][in] */ LPCWSTR sessionID,
            /* [annotation][in] */ 
            __in  IAudioVolumeDuckNotification *duckNotification);
        
        HRESULT ( STDMETHODCALLTYPE *UnregisterDuckNotification )( 
            IAudioSessionManager2 * This,
            /* [annotation][in] */ 
            __in  IAudioVolumeDuckNotification *duckNotification);
        
        END_INTERFACE
    } IAudioSessionManager2Vtbl;

    interface IAudioSessionManager2
    {
        CONST_VTBL struct IAudioSessionManager2Vtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IAudioSessionManager2_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IAudioSessionManager2_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IAudioSessionManager2_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IAudioSessionManager2_GetAudioSessionControl(This,AudioSessionGuid,StreamFlags,SessionControl)	\
    ( (This)->lpVtbl -> GetAudioSessionControl(This,AudioSessionGuid,StreamFlags,SessionControl) ) 

#define IAudioSessionManager2_GetSimpleAudioVolume(This,AudioSessionGuid,StreamFlags,AudioVolume)	\
    ( (This)->lpVtbl -> GetSimpleAudioVolume(This,AudioSessionGuid,StreamFlags,AudioVolume) ) 


#define IAudioSessionManager2_GetSessionEnumerator(This,SessionEnum)	\
    ( (This)->lpVtbl -> GetSessionEnumerator(This,SessionEnum) ) 

#define IAudioSessionManager2_RegisterSessionNotification(This,SessionNotification)	\
    ( (This)->lpVtbl -> RegisterSessionNotification(This,SessionNotification) ) 

#define IAudioSessionManager2_UnregisterSessionNotification(This,SessionNotification)	\
    ( (This)->lpVtbl -> UnregisterSessionNotification(This,SessionNotification) ) 

#define IAudioSessionManager2_RegisterDuckNotification(This,sessionID,duckNotification)	\
    ( (This)->lpVtbl -> RegisterDuckNotification(This,sessionID,duckNotification) ) 

#define IAudioSessionManager2_UnregisterDuckNotification(This,duckNotification)	\
    ( (This)->lpVtbl -> UnregisterDuckNotification(This,duckNotification) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IAudioSessionManager2_INTERFACE_DEFINED__ */


/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif



