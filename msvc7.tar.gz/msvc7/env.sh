# Microsoft Visual C++ CLI environment bash source file for msys2
# Made by lihsilyn (lihsilyn@gmail.com)
# 2018-4-24

if [ ${MSVC:=0} = 1 ]; then
	echo Error: Cannot be repeated loading
else 
	VC_HOME=/opt/msvc7
	SDK_HOME=$VC_HOME/winsdk7
	export include=`cygpath -p "$SDK_HOME/include:$VC_HOME/include" -a -w`
	export lib=`cygpath -p "$SDK_HOME/lib:$VC_HOME/lib" -a -w`
	export PATH_VC=$SDK_HOME/bin:$VC_HOME/bin
	PATH=$PATH_VC:$PATH
	alias del="cmd.exe -c del"
	echo Microsoft Visual C++ CLI environment loaded
	MSVC=1
	
fi
